#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct
{
	int cus_custkey;    	   //�˿ͱ��
	char cus_mkgsegment[20]; //��Ӧ��ĳ���г�����
}customer;				   //�˿ͽṹ�� 

typedef struct
{
	int or_orderkey;    	 //������ 
	int or_custkey;    	 //�˿ͱ��
	char or_orderdate[10];//�������� 
}orders;				 //����

typedef struct
{
	int lin_orderkey;//������
	double lin_extendedprice;//����۸�
	char lin_shipdate[10];//�������� 
}lineitem; //��Ʒ��Ϣ 

typedef struct
{
	int lin_orderkey;//������
	char or_orderdate[10];//�������� 
	double lin_extendedprice;//����۸�
}select_result;


customer * read_customer_txt() //��ȡcustomer��txt���� 
{
	FILE * fp;
	customer *a=NULL;
	a = (customer *)malloc(100*sizeof(customer));
	int i=0;
	char b;
	fp = fopen("C:\\Users\\MR6\\Desktop\\small\\1.txt","r");
	if(NULL==fp)
	{
		printf("error!");
		return NULL;
	}
	while(!feof(fp))
	{	
		fscanf(fp,"%d%c%s",&a[i].cus_custkey,&b,&a[i].cus_mkgsegment);
		i++;
	}
	fclose(fp);
	return a;
}
orders * read_orders_txt()//��ȡorders.txt���� 
{
	int i =0; 
	orders * a=NULL;
	a = (orders * )malloc(4000*sizeof(orders));
	char b,c;
	long long d;
	FILE *fp;
	fp = fopen("C:\\Users\\MR6\\Desktop\\small\\2.txt","r");
	if(fp == NULL)
	{
		printf("error!");
		return NULL;
	}
	while(!feof(fp))
	{	
		fscanf(fp,"%d%c%lld%c%s",&a[i].or_orderkey,&b,&d,&c,&a[i].or_orderdate);
		a[i].or_custkey=d%100;
		i++;
	}
	fclose(fp);
	return a;
}

lineitem * read_lineitem_txt()//��ȡlineitem.txt����
{
	FILE * fp;
	lineitem * l=NULL;
	l = (lineitem *)malloc(1000*sizeof(lineitem));
	int i=0;
	char b,c;
	fp = fopen("C:\\Users\\MR6\Desktop\\small\\3.txt","r");
	if(fp==NULL)
	{
		printf("error!");
		return NULL;
	}
	while(!feof(fp))
	{
		fscanf(fp,"%d%c%lf%c%s",&l[i].lin_orderkey,&c,&l[i].lin_extendedprice,&b,&l[i].lin_shipdate);
		i++;
	}
	fclose(fp);
	return l; 
}

select_result * select1(customer * cus,orders * ord,lineitem * item,char * order_date,char * ship_date,char * ship_type)
{
	int i,j,k,l=0,m=0;
	select_result * result1=NULL;
	select_result * result2=NULL;
	select_result  temp;
	result1 = (select_result *)malloc(1000*sizeof(select_result));
	result2 = (select_result *)malloc(1000*sizeof(select_result));
	for(i=0;i<100;i++)
	{
		if(strcmp(cus[i].cus_mkgsegment,ship_type)==0)
		{
		for(j=0;j<4000;j++)
		{
			for(k=0;k<1000;k++)
			if(cus[i].cus_custkey==ord[j].or_custkey&&ord[j].or_orderkey==item[k].lin_orderkey&&(strcmp(ord[j].or_orderdate,order_date)<0)&&(strcmp(item[k].lin_shipdate,ship_date)>0))
			{
				result1[l].lin_orderkey=item[k].lin_orderkey;
				strcpy(result1[l].or_orderdate,ord[j].or_orderdate);
				result1[l].lin_extendedprice=item[k].lin_extendedprice;
				l++;
			}
		}
		}
		else continue;
	}
	for(i=0;i<l;i++)
	{
		if(i==0)
		{
			result2[m].lin_orderkey = result1[i].lin_orderkey;
			strcpy(result2[m].or_orderdate,result1[i].or_orderdate);
			result2[m].lin_extendedprice = result1[i].lin_extendedprice;
			continue;
		}
		if(result1[i].lin_orderkey==result1[i-1].lin_orderkey)
		{
			result2[m].lin_extendedprice = result2[m].lin_extendedprice + result1[i].lin_extendedprice;
			
		}
		else
		{
			
			m++;
			result2[m].lin_orderkey = result1[i].lin_orderkey;
			strcpy(result2[m].or_orderdate,result1[i].or_orderdate);
			result2[m].lin_extendedprice = result1[i].lin_extendedprice;
			
		}
	}

    for(i=0;i<m-1;i++)
	{
		for(j=0;j<m-1-i;j++)
		{
			if(result2[j].lin_extendedprice<result2[j+1].lin_extendedprice)
			{
				//printf("123");
				temp.lin_extendedprice=result2[j].lin_extendedprice;
				temp.lin_orderkey=result2[j].lin_orderkey;
				strcpy(temp.or_orderdate,result2[j].or_orderdate);
				result2[j].lin_extendedprice=result2[j+1].lin_extendedprice;
				result2[j].lin_orderkey=result2[j+1].lin_orderkey;
				strcpy(result2[j].or_orderdate,result2[j+1].or_orderdate);
				result2[j+1].lin_extendedprice=temp.lin_extendedprice;
				result2[j+1].lin_orderkey=temp.lin_orderkey;
				strcpy(result2[j+1].or_orderdate,temp.or_orderdate);
			}
		}
	}
	return result2;
}

int run(char *a,char *b,char *c,int d)
{
	int i;
	customer * cus = NULL;
	orders * ord = NULL;
	lineitem * item = NULL;
	cus = read_customer_txt();
	ord = read_orders_txt();
	item = read_lineitem_txt();
	int limit=d;
	select_result *result=NULL;
	result=select1(cus,ord,item,b,c,a);
	printf("lin_orderkey|or_orderdate|revenue\n");
	for(i=0;i<limit;i++)
	{
		printf("%-10d|%-11s|%-20.2lf\n",result[i].lin_orderkey,result[i].or_orderdate,result[i].lin_extendedprice);
	}
	return 0;
}
int main(int argc,char **argv)
{
	int i;
	int a;
	unsigned int n=atoi(argv[4]);
	for(i=1;i<=n;i++)
	{
		unsigned int t=atoi(argv[4*i+4]);
		a=run(argv[4*i+1],argv[4*i+2],argv[4*i+3],t);
	}
	return 0;
}
